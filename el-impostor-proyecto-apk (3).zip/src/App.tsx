/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { SplashScreen } from './components/SplashScreen';
import { IntroScreen } from './components/IntroScreen';
import { PlayerCountScreen } from './components/PlayerCountScreen';
import { PlayerNamesScreen } from './components/PlayerNamesScreen';
import { CardRevealScreen } from './components/CardRevealScreen';
import { GameRunningScreen } from './components/GameRunningScreen';
import { pickGameWords } from './data/words';
import { sounds } from './utils/sound';
import { DownloadZipButton } from './components/DownloadZipButton';
import { Volume2, VolumeX } from 'lucide-react';

type GameStage =
  | 'splash'
  | 'intro'
  | 'player-count'
  | 'player-names'
  | 'card-reveal'
  | 'game-running';

export default function App() {
  const [stage, setStage] = useState<GameStage>('splash');
  const [playerCount, setPlayerCount] = useState<number>(4);
  const [players, setPlayers] = useState<string[]>([]);
  const [impostorIndex, setImpostorIndex] = useState<number>(0);
  const [mainWord, setMainWord] = useState<string>('');
  const [impostorWord, setImpostorWord] = useState<string>('');
  const [category, setCategory] = useState<string>('');
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);

  const toggleSound = () => {
    const nextState = !soundEnabled;
    sounds.enabled = nextState;
    setSoundEnabled(nextState);
  };

  // Handler when player count is confirmed
  const handleConfirmPlayerCount = (count: number) => {
    setPlayerCount(count);
    setStage('player-names');
  };

  // Handler when player names are confirmed
  const handleConfirmNames = (names: string[]) => {
    setPlayers(names);

    // Pick 1 impostor at random
    const randomImpostor = Math.floor(Math.random() * names.length);
    setImpostorIndex(randomImpostor);

    // Pick words from 500 options database
    const { commonWord, impostorWord: impWord, category: cat } = pickGameWords();
    setMainWord(commonWord);
    setImpostorWord(impWord);
    setCategory(cat);

    setStage('card-reveal');
  };

  // Handler when "Empezar juego" is clicked on the last card
  const handleStartGame = () => {
    setStage('game-running');
  };

  // Handler when "Reiniciar" is clicked -> vuelve a solicitar la cantidad de jugadores a jugar
  const handleRestart = () => {
    setStage('player-count');
  };

  return (
    <main className="w-full min-h-screen bg-slate-950 text-slate-100 flex flex-col relative font-sans">
      {/* Botón para descargar el proyecto en archivo ZIP listo para GitHub y APK */}
      <DownloadZipButton />

      {/* Sound toggle button (available on non-splash screens) */}
      {stage !== 'splash' && (
        <button
          onClick={toggleSound}
          className="fixed top-4 right-4 z-50 p-2.5 rounded-full bg-slate-900/80 border border-slate-800 text-slate-400 hover:text-slate-200 transition-colors shadow-lg backdrop-blur-sm cursor-pointer"
          title={soundEnabled ? 'Silenciar sonidos' : 'Activar sonidos'}
          aria-label={soundEnabled ? 'Silenciar sonidos' : 'Activar sonidos'}
        >
          {soundEnabled ? (
            <Volume2 className="w-4 h-4 text-red-400" />
          ) : (
            <VolumeX className="w-4 h-4 text-slate-500" />
          )}
        </button>
      )}

      {/* 1. Splash Screen */}
      {stage === 'splash' && (
        <SplashScreen onComplete={() => setStage('intro')} />
      )}

      {/* 2. Intro Screen (Word by word: Cuidado, hay un impostor entre nosotros) */}
      {stage === 'intro' && (
        <IntroScreen onFinish={() => setStage('player-count')} />
      )}

      {/* 3. Player Count Screen */}
      {stage === 'player-count' && (
        <PlayerCountScreen
          initialCount={playerCount}
          onConfirm={handleConfirmPlayerCount}
        />
      )}

      {/* 4. Player Names Screen */}
      {stage === 'player-names' && (
        <PlayerNamesScreen
          playerCount={playerCount}
          onBack={() => setStage('player-count')}
          onConfirmNames={handleConfirmNames}
        />
      )}

      {/* 5. Card Reveal Screen (Hold to flip 3D card) */}
      {stage === 'card-reveal' && (
        <CardRevealScreen
          players={players}
          impostorIndex={impostorIndex}
          mainWord={mainWord}
          impostorWord={impostorWord}
          category={category}
          onStartGame={handleStartGame}
        />
      )}

      {/* 6. Game Running Screen (Only shows "Reiniciar" button) */}
      {stage === 'game-running' && (
        <GameRunningScreen
          onRestart={handleRestart}
          impostorName={players[impostorIndex] || `Jugador ${impostorIndex + 1}`}
          mainWord={mainWord}
          impostorWord={impostorWord}
          playersCount={players.length}
        />
      )}
    </main>
  );
}
