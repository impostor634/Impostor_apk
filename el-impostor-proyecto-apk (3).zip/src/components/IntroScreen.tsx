import React, { useEffect, useState, useRef, useCallback } from 'react';
import { sounds } from '../utils/sound';
import { ChevronRight } from 'lucide-react';

interface IntroScreenProps {
  onFinish: () => void;
}

const WORDS = ["Cuidado,", "hay", "un", "impostor", "entre", "nosotros"];

export const IntroScreen: React.FC<IntroScreenProps> = ({ onFinish }) => {
  const [revealedCount, setRevealedCount] = useState<number>(0);
  const [isComplete, setIsComplete] = useState<boolean>(false);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Play word sound when revealed
  const advanceWord = useCallback(() => {
    setRevealedCount((prev) => {
      const next = prev + 1;
      sounds.playWordThud();
      if (next >= WORDS.length) {
        setIsComplete(true);
        if (timerRef.current) clearInterval(timerRef.current);
      }
      return next;
    });
  }, []);

  useEffect(() => {
    // Start revealing word by word
    timerRef.current = setInterval(() => {
      advanceWord();
    }, 450);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [advanceWord]);

  // Handle tap anywhere on screen to accelerate
  const handleScreenTap = () => {
    if (!isComplete) {
      // Accelerate: reveal all words immediately
      if (timerRef.current) clearInterval(timerRef.current);
      setRevealedCount(WORDS.length);
      setIsComplete(true);
      sounds.playWordThud();
    } else {
      // If already complete, proceed to next screen
      sounds.playClick();
      onFinish();
    }
  };

  return (
    <div
      onClick={handleScreenTap}
      className="relative min-h-screen w-full bg-slate-950 text-white flex flex-col justify-between items-center px-6 py-12 cursor-pointer select-none overflow-hidden"
    >
      {/* Background ambient lighting */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(220,38,38,0.12)_0%,transparent_70%)] pointer-events-none" />

      {/* Top hint */}
      <div className="text-xs uppercase tracking-widest text-slate-500 font-mono text-center">
        {!isComplete ? "Toca la pantalla para apresurar" : "Mensaje transmitido"}
      </div>

      {/* Center text container */}
      <div className="max-w-2xl text-center px-4 flex flex-wrap justify-center items-center gap-x-3.5 gap-y-3">
        {WORDS.map((word, index) => {
          const isRevealed = index < revealedCount;
          const isImpostorWord = word.toLowerCase().includes("impostor");

          return (
            <span
              key={index}
              className={`transition-all duration-300 transform inline-block text-3xl sm:text-5xl md:text-6xl font-black tracking-tight ${
                isRevealed
                  ? "opacity-100 scale-100 translate-y-0"
                  : "opacity-0 scale-75 translate-y-4"
              } ${
                isImpostorWord
                  ? "text-red-500 drop-shadow-[0_0_25px_rgba(239,68,68,0.7)] uppercase font-mono"
                  : "text-slate-100"
              }`}
            >
              {word}
            </span>
          );
        })}
      </div>

      {/* Bottom action prompt */}
      <div className="flex flex-col items-center gap-3">
        {isComplete ? (
          <button
            onClick={(e) => {
              e.stopPropagation();
              sounds.playClick();
              onFinish();
            }}
            className="flex items-center gap-2 px-6 py-3 rounded-full bg-red-600 hover:bg-red-500 text-white font-semibold text-base transition-all duration-200 shadow-lg shadow-red-600/40 hover:scale-105 active:scale-95 animate-bounce"
          >
            <span>Continuar</span>
            <ChevronRight className="w-5 h-5" />
          </button>
        ) : (
          <p className="text-xs text-slate-400 font-mono animate-pulse">
            Toque en cualquier parte para revelar todo...
          </p>
        )}

        <p className="text-[11px] text-slate-600">
          created by <span className="text-slate-400">Kendry</span>
        </p>
      </div>
    </div>
  );
};
