import React, { useEffect, useState } from 'react';
import { ShieldAlert, EyeOff } from 'lucide-react';

interface SplashScreenProps {
  onComplete: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onComplete }) => {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const duration = 2800; // ~2.8s
    const intervalTime = 30;
    const step = 100 / (duration / intervalTime);

    const timer = setInterval(() => {
      setProgress((prev) => {
        const next = prev + step;
        if (next >= 100) {
          clearInterval(timer);
          setTimeout(onComplete, 400);
          return 100;
        }
        return next;
      });
    }, intervalTime);

    return () => clearInterval(timer);
  }, [onComplete]);

  return (
    <div className="relative min-h-screen w-full bg-slate-950 text-slate-100 flex flex-col justify-between items-center px-6 py-8 select-none overflow-hidden">
      {/* Background glow effects */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-red-600/15 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-10 right-10 w-64 h-64 bg-rose-900/10 rounded-full blur-2xl pointer-events-none" />

      {/* Top spacer */}
      <div className="w-full flex justify-center pt-4">
        <span className="text-[11px] uppercase tracking-[0.3em] text-red-500/70 font-semibold flex items-center gap-1.5">
          <EyeOff className="w-3.5 h-3.5 animate-pulse text-red-500" />
          Protocolo Secreto
        </span>
      </div>

      {/* Center Logo & Loading Bar */}
      <div className="w-full max-w-sm flex flex-col items-center text-center my-auto">
        {/* Emblem / Badge */}
        <div className="relative mb-6">
          <div className="w-24 h-24 rounded-2xl bg-gradient-to-br from-red-600 to-rose-950 flex items-center justify-center shadow-2xl shadow-red-900/50 border border-red-500/40 transform rotate-3 hover:rotate-0 transition-transform duration-300">
            <ShieldAlert className="w-12 h-12 text-white drop-shadow-md" />
          </div>
          <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-red-500 border-2 border-slate-950 flex items-center justify-center animate-ping" />
        </div>

        {/* Title */}
        <h1 className="text-4xl sm:text-5xl font-extrabold tracking-wider uppercase text-white font-mono drop-shadow-[0_2px_15px_rgba(239,68,68,0.4)]">
          El Impostor
        </h1>
        <p className="text-sm tracking-widest text-slate-400 uppercase mt-2 font-medium">
          Deducción &bull; Sigilo &bull; Misterio
        </p>

        {/* Loading bar container */}
        <div className="w-full mt-10">
          <div className="flex justify-between text-xs text-slate-400 font-mono mb-2">
            <span>Iniciando sistema...</span>
            <span className="text-red-400 font-bold">{Math.round(progress)}%</span>
          </div>

          <div className="w-full h-3 bg-slate-900 rounded-full p-0.5 border border-slate-800 shadow-inner overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-red-600 via-rose-500 to-amber-500 rounded-full transition-all duration-75 shadow-lg shadow-red-600/50"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>
      </div>

      {/* Bottom watermark */}
      <div className="w-full flex justify-center pb-2">
        <p className="text-xs text-slate-500 tracking-wider font-light">
          created by <span className="text-slate-300 font-medium">Kendry</span>
        </p>
      </div>
    </div>
  );
};
