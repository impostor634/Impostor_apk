import React, { useState } from 'react';
import { RotateCcw, Eye, EyeOff } from 'lucide-react';
import { sounds } from '../utils/sound';

interface GameRunningScreenProps {
  onRestart: () => void;
  impostorName: string;
  mainWord: string;
  impostorWord: string;
  playersCount: number;
}

export const GameRunningScreen: React.FC<GameRunningScreenProps> = ({
  onRestart,
  impostorName,
  mainWord,
  impostorWord,
  playersCount,
}) => {
  const [showSummary, setShowSummary] = useState<boolean>(false);

  const handleRestart = () => {
    sounds.playClick();
    onRestart();
  };

  return (
    <div className="relative min-h-screen w-full bg-slate-950 text-slate-100 flex flex-col justify-between items-center px-4 py-10 select-none overflow-hidden">
      {/* Ambient background glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-red-600/10 rounded-full blur-3xl pointer-events-none" />

      {/* Top minimal status */}
      <div className="w-full flex justify-center pt-2">
        <span className="text-xs uppercase tracking-widest text-red-500/80 font-mono font-semibold">
          &bull; Partida en progreso &bull;
        </span>
      </div>

      {/* Center prominent Reiniciar section */}
      <div className="w-full max-w-sm flex flex-col items-center text-center my-auto">
        <h2 className="text-3xl sm:text-4xl font-black uppercase text-white font-mono tracking-wider drop-shadow-md mb-2">
          ¡Juego en curso!
        </h2>
        <p className="text-sm text-slate-400 mb-8 max-w-xs">
          Debatan, hagan preguntas y descubran quién es el impostor.
        </p>

        {/* El botón principal de Reiniciar */}
        <button
          onClick={handleRestart}
          className="w-full py-5 px-8 rounded-2xl bg-gradient-to-r from-red-600 via-rose-600 to-red-700 hover:from-red-500 hover:to-rose-500 text-white font-extrabold text-xl flex items-center justify-center gap-3 shadow-2xl shadow-red-700/50 transition-all duration-150 active:scale-95 border border-red-500/30 cursor-pointer"
        >
          <RotateCcw className="w-6 h-6 stroke-[2.5]" />
          <span>Reiniciar</span>
        </button>

        {/* Opcional: Ver quién era el impostor tras terminar la ronda */}
        <div className="mt-8 w-full flex flex-col items-center">
          <button
            onClick={() => {
              sounds.playClick();
              setShowSummary((prev) => !prev);
            }}
            className="flex items-center gap-1.5 text-xs text-slate-500 hover:text-slate-300 font-mono underline decoration-dotted transition-colors"
          >
            {showSummary ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
            <span>{showSummary ? 'Ocultar soluciones' : 'Revelar impostor y palabras'}</span>
          </button>

          {showSummary && (
            <div className="mt-4 w-full bg-slate-900/90 border border-slate-800 rounded-2xl p-4 text-left font-mono text-xs space-y-2 shadow-xl animate-in fade-in duration-200">
              <div className="flex justify-between items-center text-slate-300">
                <span className="text-slate-500">Impostor ({playersCount} jugadores):</span>
                <span className="text-red-400 font-bold uppercase">{impostorName}</span>
              </div>
              <div className="flex justify-between items-center text-slate-300">
                <span className="text-slate-500">Palabra de la mayoría:</span>
                <span className="text-emerald-400 font-bold uppercase">{mainWord}</span>
              </div>
              <div className="flex justify-between items-center text-slate-300">
                <span className="text-slate-500">Palabra del impostor:</span>
                <span className="text-amber-400 font-bold uppercase">{impostorWord}</span>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Bottom watermark */}
      <div className="w-full flex justify-center pb-2">
        <p className="text-xs text-slate-500 font-light">
          created by <span className="text-slate-400">Kendry</span>
        </p>
      </div>
    </div>
  );
};
