import React, { useState } from 'react';
import { Download, Check, Loader2, Github, HelpCircle, X } from 'lucide-react';
import { Capacitor } from '@capacitor/core';
import { sounds } from '../utils/sound';

export const DownloadZipButton: React.FC = () => {
  const [downloading, setDownloading] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);

  // Asegurar que el botón salga ÚNICAMENTE en el preview web y nunca dentro del APK
  const isNative = Capacitor.isNativePlatform();
  const isAppProtocol =
    typeof window !== 'undefined' &&
    (window.location.protocol === 'capacitor:' || window.location.protocol === 'file:');

  const isPreview =
    typeof window !== 'undefined' &&
    !isNative &&
    !isAppProtocol &&
    (window.location.hostname.includes('run.app') ||
      window.location.hostname.includes('googleusercontent.com') ||
      window.location.hostname === 'localhost' ||
      window.location.hostname === '127.0.0.1' ||
      import.meta.env.DEV);

  // Si está dentro de la APK compilada o en producción instalada, no renderizar nada
  if (!isPreview) {
    return null;
  }

  const handleDownload = async () => {
    try {
      sounds.playClick();
      setDownloading(true);

      const response = await fetch('/api/download-zip');
      if (!response.ok) {
        throw new Error('Error al generar el ZIP en el servidor');
      }

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = 'el-impostor-proyecto-apk.zip';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);

      setDownloadSuccess(true);
      setTimeout(() => setDownloadSuccess(false), 4000);
    } catch (err) {
      console.error('Error al descargar ZIP:', err);
      // Fallback: abrir directamente el endpoint
      window.location.href = '/api/download-zip';
    } finally {
      setDownloading(false);
    }
  };

  return (
    <>
      {/* Botón flotante superior */}
      <div className="fixed top-4 left-4 z-50 flex items-center gap-2">
        <button
          onClick={handleDownload}
          disabled={downloading}
          className="flex items-center gap-2 px-3.5 py-2 rounded-full bg-slate-900/90 hover:bg-slate-800 border border-slate-700/80 text-white text-xs font-semibold shadow-lg shadow-black/50 backdrop-blur-sm transition-all duration-200 active:scale-95 disabled:opacity-50 cursor-pointer"
          title="Descargar código del proyecto en archivo .ZIP para compilar APK en GitHub"
        >
          {downloading ? (
            <Loader2 className="w-3.5 h-3.5 animate-spin text-red-400" />
          ) : downloadSuccess ? (
            <Check className="w-3.5 h-3.5 text-emerald-400" />
          ) : (
            <Download className="w-3.5 h-3.5 text-red-400" />
          )}
          <span>
            {downloading
              ? 'Generando ZIP...'
              : downloadSuccess
              ? '¡Descargado!'
              : 'Descargar ZIP (APK)'}
          </span>
        </button>

        <button
          onClick={() => {
            sounds.playClick();
            setShowModal(true);
          }}
          className="p-2 rounded-full bg-slate-900/90 hover:bg-slate-800 border border-slate-700/80 text-slate-400 hover:text-white transition-all shadow-lg backdrop-blur-sm cursor-pointer"
          title="Ver instrucciones de GitHub para obtener el APK"
        >
          <HelpCircle className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Modal de instrucciones para GitHub & APK */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 max-w-md w-full shadow-2xl relative text-slate-200">
            {/* Botón cerrar */}
            <button
              onClick={() => {
                sounds.playClick();
                setShowModal(false);
              }}
              className="absolute top-4 right-4 p-1.5 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
            >
              <X className="w-4 h-4" />
            </button>

            {/* Header del modal */}
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl bg-red-950/80 border border-red-800 flex items-center justify-center text-red-400">
                <Github className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">
                  Cómo generar tu .APK en GitHub
                </h3>
                <p className="text-xs text-slate-400">
                  El archivo ZIP ya viene configurado con GitHub Actions.
                </p>
              </div>
            </div>

            {/* Pasos */}
            <ol className="space-y-3 text-xs text-slate-300 font-sans my-4">
              <li className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-full bg-slate-800 text-red-400 font-mono font-bold flex items-center justify-center shrink-0 text-[11px]">
                  1
                </span>
                <span>
                  Descarga el <strong>.ZIP</strong> presionando el botón{' '}
                  <strong className="text-white">"Descargar ZIP (APK)"</strong>.
                </span>
              </li>
              <li className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-full bg-slate-800 text-red-400 font-mono font-bold flex items-center justify-center shrink-0 text-[11px]">
                  2
                </span>
                <span>
                  Descomprime el ZIP y sube los archivos a un repositorio nuevo en{' '}
                  <strong>GitHub</strong>.
                </span>
              </li>
              <li className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-full bg-slate-800 text-red-400 font-mono font-bold flex items-center justify-center shrink-0 text-[11px]">
                  3
                </span>
                <span>
                  En GitHub, dirígete a la pestaña <strong>"Actions"</strong>. Verás el flujo{' '}
                  <em>"Construir APK de El Impostor"</em> compilando tu APK.
                </span>
              </li>
              <li className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-full bg-slate-800 text-red-400 font-mono font-bold flex items-center justify-center shrink-0 text-[11px]">
                  4
                </span>
                <span>
                  Al terminar (en 2 min), ve a <strong>Artifacts</strong> y descarga tu{' '}
                  <strong className="text-emerald-400">app-debug.apk</strong> listo para instalar en Android.
                </span>
              </li>
            </ol>

            {/* Botón de descarga en el modal */}
            <div className="pt-2">
              <button
                onClick={handleDownload}
                disabled={downloading}
                className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white font-bold text-sm flex items-center justify-center gap-2 shadow-lg shadow-red-600/30 transition-all cursor-pointer"
              >
                {downloading ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Download className="w-4 h-4" />
                )}
                <span>
                  {downloading ? 'Descargando ZIP...' : 'Descargar Archivo ZIP Ahora'}
                </span>
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
