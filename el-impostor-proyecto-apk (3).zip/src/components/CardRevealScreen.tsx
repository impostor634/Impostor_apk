import React, { useState } from 'react';
import { sounds } from '../utils/sound';
import { Eye, Lock, ArrowRight, Play, Fingerprint, ShieldCheck } from 'lucide-react';

interface CardRevealScreenProps {
  players: string[];
  impostorIndex: number;
  mainWord: string;
  impostorWord: string;
  category: string;
  onStartGame: () => void;
}

export const CardRevealScreen: React.FC<CardRevealScreenProps> = ({
  players,
  impostorIndex,
  mainWord,
  impostorWord,
  onStartGame,
}) => {
  const [currentPlayerIndex, setCurrentPlayerIndex] = useState<number>(0);
  const [isFlipped, setIsFlipped] = useState<boolean>(false);
  const [hasPeeked, setHasPeeked] = useState<boolean>(false);

  const currentPlayerName = players[currentPlayerIndex];
  const isLastPlayer = currentPlayerIndex === players.length - 1;
  const isCurrentImpostor = currentPlayerIndex === impostorIndex;

  // The secret word for the current player
  const currentWord = isCurrentImpostor ? impostorWord : mainWord;

  // Handle touch / pointer down
  const handlePressStart = (e: React.PointerEvent | React.TouchEvent | React.MouseEvent) => {
    // Prevent default context menus or selection
    e.preventDefault();
    if (!isFlipped) {
      sounds.playFlip();
      setIsFlipped(true);
    }
  };

  // Handle release / pointer up
  const handlePressEnd = () => {
    if (isFlipped) {
      sounds.playUnflip();
      setIsFlipped(false);
      setHasPeeked(true);
    }
  };

  // Advance to next player
  const handleNextPlayer = () => {
    sounds.playClick();
    if (isLastPlayer) {
      onStartGame();
    } else {
      setCurrentPlayerIndex((prev) => prev + 1);
      setIsFlipped(false);
      setHasPeeked(false);
    }
  };

  return (
    <div className="relative min-h-screen w-full bg-slate-950 text-slate-100 flex flex-col justify-between items-center px-4 py-6 select-none no-select overflow-hidden">
      {/* Background atmosphere */}
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-red-600/10 rounded-full blur-3xl pointer-events-none" />

      {/* Top Status & Progress Bar */}
      <div className="w-full max-w-sm flex flex-col items-center mt-2">
        <div className="flex items-center justify-between w-full text-xs font-mono text-slate-400 mb-2">
          <span>JUGADOR {currentPlayerIndex + 1} DE {players.length}</span>
          <span className="text-red-400 font-bold">
            {Math.round(((currentPlayerIndex + 1) / players.length) * 100)}%
          </span>
        </div>

        {/* Progress indicator dots or bar */}
        <div className="w-full flex gap-1.5 mb-2">
          {players.map((_, idx) => (
            <div
              key={idx}
              className={`h-1.5 flex-1 rounded-full transition-all duration-300 ${
                idx < currentPlayerIndex
                  ? 'bg-red-500'
                  : idx === currentPlayerIndex
                  ? 'bg-white'
                  : 'bg-slate-800'
              }`}
            />
          ))}
        </div>
      </div>

      {/* 3D Flip Card Container */}
      <div className="w-full max-w-xs sm:max-w-sm my-auto flex flex-col items-center">
        {/* Pass device message */}
        <p className="text-xs uppercase tracking-widest text-slate-400 font-mono mb-3 text-center">
          Pasa el dispositivo a <strong className="text-white">{currentPlayerName}</strong>
        </p>

        {/* The 3D Interactive Card */}
        <div
          className="perspective-1000 w-full h-84 sm:h-96 cursor-pointer touch-none"
          onPointerDown={handlePressStart}
          onPointerUp={handlePressEnd}
          onPointerLeave={handlePressEnd}
          onPointerCancel={handlePressEnd}
          onContextMenu={(e) => e.preventDefault()}
        >
          <div
            className={`w-full h-full relative transition-transform duration-500 transform-style-3d rounded-3xl ${
              isFlipped ? 'rotate-y-180' : ''
            }`}
          >
            {/* FRONT FACE (Player Name) */}
            <div className="absolute inset-0 w-full h-full backface-hidden rounded-3xl bg-gradient-to-b from-slate-900 via-slate-900 to-slate-950 border-2 border-slate-700/80 p-6 flex flex-col justify-between items-center text-center shadow-2xl shadow-black/80">
              {/* Card Header Badge */}
              <div className="w-full flex items-center justify-between text-slate-500 font-mono text-xs">
                <span className="flex items-center gap-1 text-red-400 font-semibold tracking-wider">
                  <Lock className="w-3.5 h-3.5" /> CONFIDENCIAL
                </span>
                <span>#{currentPlayerIndex + 1}</span>
              </div>

              {/* Player Name Display */}
              <div className="my-auto flex flex-col items-center">
                <div className="w-20 h-20 rounded-full bg-slate-800/80 border border-slate-700 flex items-center justify-center mb-4 shadow-inner">
                  <Eye className="w-10 h-10 text-red-400/90 animate-pulse" />
                </div>
                <span className="text-xs uppercase tracking-widest text-slate-400 font-mono">
                  Turno de:
                </span>
                <h3 className="text-3xl font-black text-white mt-1 tracking-tight drop-shadow-md break-words max-w-[250px]">
                  {currentPlayerName}
                </h3>
              </div>

              {/* Card Footer Instruction */}
              <div className="w-full bg-slate-950/70 border border-slate-800 rounded-2xl py-3 px-4 flex items-center justify-center gap-2">
                <Fingerprint className="w-5 h-5 text-red-500 animate-bounce" />
                <span className="text-xs font-semibold text-slate-200">
                  Mantén presionado para revelar
                </span>
              </div>
            </div>

            {/* BACK FACE (Secret Word) */}
            <div className="absolute inset-0 w-full h-full backface-hidden rotate-y-180 rounded-3xl bg-gradient-to-b from-slate-950 via-red-950/40 to-slate-950 border-2 border-red-500/80 p-6 flex flex-col justify-between items-center text-center shadow-2xl shadow-red-950/80">
              {/* Back Card Header */}
              <div className="w-full flex items-center justify-between text-xs font-mono">
                <span className="flex items-center gap-1 text-emerald-400 font-bold uppercase tracking-wider">
                  <ShieldCheck className="w-4 h-4" /> Código Asignado
                </span>
                <span className="text-slate-500">{currentPlayerName}</span>
              </div>

              {/* Secret Word Display */}
              <div className="my-auto flex flex-col items-center px-2">
                <span className="text-xs uppercase tracking-widest text-red-400 font-mono mb-2 font-semibold">
                  Tu palabra secreta es:
                </span>
                <div className="bg-slate-900/90 border border-red-500/30 px-6 py-4 rounded-2xl shadow-xl w-full">
                  <span className="text-3xl sm:text-4xl font-black text-white tracking-wide uppercase font-mono drop-shadow-[0_2px_12px_rgba(239,68,68,0.5)]">
                    {currentWord}
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 mt-3 font-medium">
                  Memorízala bien y no permitas que nadie vea la pantalla.
                </p>
              </div>

              {/* Back Card Footer Instruction */}
              <div className="w-full bg-red-950/50 border border-red-900/50 rounded-2xl py-2.5 px-4 text-center">
                <span className="text-xs text-red-300 font-bold animate-pulse">
                  Suelta la tarjeta para ocultar
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Action Button Below Card */}
        {/* Appears when the card is released after being viewed */}
        <div className="w-full min-h-[72px] mt-6 flex items-center justify-center">
          {hasPeeked ? (
            <button
              onClick={handleNextPlayer}
              className={`w-full py-4 px-6 rounded-2xl font-bold text-lg flex items-center justify-center gap-3 transition-all duration-200 active:scale-[0.98] shadow-xl ${
                isLastPlayer
                  ? 'bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-500 hover:to-green-500 text-white shadow-emerald-900/50 animate-pulse'
                  : 'bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white shadow-red-900/50'
              }`}
            >
              <span>{isLastPlayer ? 'Empezar juego' : 'pasar a otro jugador'}</span>
              {isLastPlayer ? (
                <Play className="w-5 h-5 fill-current" />
              ) : (
                <ArrowRight className="w-5 h-5" />
              )}
            </button>
          ) : (
            <p className="text-xs text-slate-500 font-mono text-center">
              Mantén presionada la tarjeta para leer tu palabra secreta.
            </p>
          )}
        </div>
      </div>

      {/* Bottom watermark */}
      <div className="w-full flex justify-center pb-2">
        <p className="text-xs text-slate-500 font-light">
          created by <span className="text-slate-400">Kendry</span>
        </p>
      </div>
    </div>
  );
};
