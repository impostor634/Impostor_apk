import React, { useState } from 'react';
import { User, Sparkles, RotateCcw, ArrowRight, ArrowLeft } from 'lucide-react';
import { sounds } from '../utils/sound';

interface PlayerNamesScreenProps {
  playerCount: number;
  onBack: () => void;
  onConfirmNames: (playerNames: string[]) => void;
}

const FUN_ALIASES = [
  'Fantasma', 'Sombra', 'Halcón', 'Cobra', 'Centinela',
  'Fénix', 'Viper', 'Espectro', 'Lobo', 'Zorro',
  'Oráculo', 'Neo', 'Titán', 'Raven', 'Eclipse'
];

export const PlayerNamesScreen: React.FC<PlayerNamesScreenProps> = ({
  playerCount,
  onBack,
  onConfirmNames,
}) => {
  // Initialize with default names: "Jugador 1", "Jugador 2", ...
  const [names, setNames] = useState<string[]>(() =>
    Array.from({ length: playerCount }, (_, i) => `Jugador ${i + 1}`)
  );

  const handleNameChange = (index: number, val: string) => {
    const updated = [...names];
    updated[index] = val;
    setNames(updated);
  };

  const handleResetToDefault = () => {
    sounds.playClick();
    setNames(Array.from({ length: playerCount }, (_, i) => `Jugador ${i + 1}`));
  };

  const handleRandomizeAliases = () => {
    sounds.playClick();
    const shuffled = [...FUN_ALIASES].sort(() => 0.5 - Math.random());
    setNames(
      Array.from({ length: playerCount }, (_, i) => shuffled[i % shuffled.length] || `Jugador ${i + 1}`)
    );
  };

  const handleConfirm = () => {
    sounds.playClick();
    // Ensure no empty names; fallback to "Jugador X" if blank
    const cleanNames = names.map((name, i) =>
      name.trim() !== '' ? name.trim() : `Jugador ${i + 1}`
    );
    onConfirmNames(cleanNames);
  };

  return (
    <div className="relative min-h-screen w-full bg-slate-950 text-slate-100 flex flex-col justify-between items-center px-4 py-6 select-none">
      {/* Background glow */}
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-red-600/10 rounded-full blur-3xl pointer-events-none" />

      {/* Top Header */}
      <div className="w-full max-w-md flex flex-col items-center text-center mt-2">
        <div className="w-full flex items-center justify-between mb-2">
          <button
            onClick={() => {
              sounds.playClick();
              onBack();
            }}
            className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white transition-colors"
            title="Cambiar cantidad de jugadores"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <span className="text-xs uppercase tracking-wider text-slate-400 font-mono">
            Paso 2 de 3
          </span>
          <div className="w-9" /> {/* Spacer */}
        </div>

        <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
          Nombres de los Jugadores
        </h2>
        <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-sm">
          Puedes personalizar cada nombre o dejar los predeterminados.
        </p>

        {/* Quick actions for names */}
        <div className="flex items-center gap-2 mt-3">
          <button
            onClick={handleResetToDefault}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-400 hover:text-slate-200 text-xs font-medium transition-all"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Nombres por defecto</span>
          </button>
          <button
            onClick={handleRandomizeAliases}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-amber-400/90 hover:text-amber-300 text-xs font-medium transition-all"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Nombres de agentes</span>
          </button>
        </div>
      </div>

      {/* Players List Scroll Area */}
      <div className="w-full max-w-md my-4 flex-1 overflow-y-auto max-h-[55vh] pr-1 space-y-2.5">
        {names.map((name, index) => (
          <div
            key={index}
            className="bg-slate-900/80 border border-slate-800/90 rounded-2xl p-3 flex items-center gap-3 shadow-md focus-within:border-red-500/70 focus-within:ring-1 focus-within:ring-red-500/40 transition-all"
          >
            <div className="w-9 h-9 rounded-xl bg-slate-800 flex items-center justify-center font-mono font-bold text-red-400 text-sm border border-slate-700/60 shrink-0">
              #{index + 1}
            </div>

            <div className="flex-1">
              <label
                htmlFor={`player-input-${index}`}
                className="block text-[10px] font-mono uppercase tracking-wider text-slate-400 mb-0.5"
              >
                Jugador {index + 1}
              </label>
              <div className="relative flex items-center">
                <input
                  id={`player-input-${index}`}
                  type="text"
                  maxLength={20}
                  value={name}
                  onChange={(e) => handleNameChange(index, e.target.value)}
                  placeholder={`Jugador ${index + 1}`}
                  className="w-full bg-transparent text-white font-medium text-sm focus:outline-none placeholder:text-slate-600"
                />
                <User className="w-4 h-4 text-slate-600 absolute right-1 pointer-events-none" />
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Bottom Confirm Button */}
      <div className="w-full max-w-md flex flex-col items-center gap-2 pt-2">
        <button
          onClick={handleConfirm}
          className="w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white font-bold text-lg flex items-center justify-center gap-3 shadow-xl shadow-red-600/30 transition-all duration-150 active:scale-[0.98]"
        >
          <span>Repartir palabras secretas</span>
          <ArrowRight className="w-5 h-5" />
        </button>

        <p className="text-xs text-slate-500 font-light">
          created by <span className="text-slate-400">Kendry</span>
        </p>
      </div>
    </div>
  );
};
