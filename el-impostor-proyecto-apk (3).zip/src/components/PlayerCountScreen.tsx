import React, { useState } from 'react';
import { Users, Plus, Minus, ArrowRight, ShieldCheck, UserX } from 'lucide-react';
import { sounds } from '../utils/sound';

interface PlayerCountScreenProps {
  initialCount?: number;
  onConfirm: (count: number) => void;
}

export const PlayerCountScreen: React.FC<PlayerCountScreenProps> = ({
  initialCount = 4,
  onConfirm,
}) => {
  const [count, setCount] = useState<number>(initialCount);

  const increment = () => {
    if (count < 20) {
      sounds.playClick();
      setCount((prev) => prev + 1);
    }
  };

  const decrement = () => {
    if (count > 3) {
      sounds.playClick();
      setCount((prev) => prev - 1);
    }
  };

  const handlePreset = (num: number) => {
    sounds.playClick();
    setCount(num);
  };

  const handleConfirm = () => {
    sounds.playClick();
    onConfirm(count);
  };

  return (
    <div className="relative min-h-screen w-full bg-slate-950 text-slate-100 flex flex-col justify-between items-center px-4 py-8 select-none">
      {/* Background glow */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 h-80 bg-red-600/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="w-full max-w-md flex flex-col items-center text-center mt-4">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-red-950/60 border border-red-800/40 text-red-400 text-xs font-mono uppercase tracking-wider mb-3">
          <Users className="w-3.5 h-3.5" />
          Configuración de la partida
        </div>
        <h2 className="text-3xl font-extrabold tracking-tight text-white">
          ¿Cuántos jugadores son?
        </h2>
        <p className="text-sm text-slate-400 mt-1 max-w-xs">
          Selecciona la cantidad de participantes que jugarán en esta ronda.
        </p>
      </div>

      {/* Counter Controls */}
      <div className="w-full max-w-sm flex flex-col items-center my-6">
        <div className="w-full bg-slate-900/90 border border-slate-800 rounded-3xl p-6 flex flex-col items-center shadow-2xl backdrop-blur-sm">
          {/* Main counter display */}
          <div className="flex items-center justify-between w-full mb-6">
            <button
              onClick={decrement}
              disabled={count <= 3}
              aria-label="Disminuir jugadores"
              className="w-14 h-14 rounded-2xl bg-slate-800 hover:bg-slate-700 disabled:opacity-30 disabled:hover:bg-slate-800 text-white flex items-center justify-center transition-all duration-150 active:scale-90 border border-slate-700"
            >
              <Minus className="w-6 h-6" />
            </button>

            <div className="flex flex-col items-center">
              <span className="text-6xl font-black font-mono text-white tracking-tight drop-shadow-md">
                {count}
              </span>
              <span className="text-xs uppercase tracking-wider text-slate-400 font-semibold mt-1">
                Jugadores
              </span>
            </div>

            <button
              onClick={increment}
              disabled={count >= 20}
              aria-label="Aumentar jugadores"
              className="w-14 h-14 rounded-2xl bg-slate-800 hover:bg-slate-700 disabled:opacity-30 disabled:hover:bg-slate-800 text-white flex items-center justify-center transition-all duration-150 active:scale-90 border border-slate-700"
            >
              <Plus className="w-6 h-6" />
            </button>
          </div>

          {/* Quick preset chips */}
          <div className="w-full flex items-center justify-center gap-2 pt-2 border-t border-slate-800/80">
            <span className="text-xs text-slate-500 font-medium mr-1">Rápido:</span>
            {[3, 4, 5, 6, 8, 10].map((num) => (
              <button
                key={num}
                onClick={() => handlePreset(num)}
                className={`w-8 h-8 rounded-lg text-xs font-mono font-bold transition-all ${
                  count === num
                    ? 'bg-red-600 text-white shadow-md shadow-red-600/40 scale-105'
                    : 'bg-slate-800/80 hover:bg-slate-700 text-slate-300'
                }`}
              >
                {num}
              </button>
            ))}
          </div>

          {/* Distribution preview info */}
          <div className="w-full mt-6 bg-slate-950/70 border border-slate-800 rounded-xl p-3 flex items-center justify-around text-xs font-medium">
            <div className="flex items-center gap-1.5 text-slate-300">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>{count - 1} Inocentes</span>
            </div>
            <div className="h-4 w-px bg-slate-800" />
            <div className="flex items-center gap-1.5 text-red-400">
              <UserX className="w-4 h-4 text-red-500" />
              <span>1 Impostor</span>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Confirm Button */}
      <div className="w-full max-w-sm flex flex-col items-center gap-3">
        <button
          onClick={handleConfirm}
          className="w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white font-bold text-lg flex items-center justify-center gap-3 shadow-xl shadow-red-600/30 transition-all duration-150 active:scale-[0.98]"
        >
          <span>Confirmar cantidad ({count})</span>
          <ArrowRight className="w-5 h-5" />
        </button>

        <p className="text-xs text-slate-500 font-light">
          created by <span className="text-slate-400">Kendry</span>
        </p>
      </div>
    </div>
  );
};
