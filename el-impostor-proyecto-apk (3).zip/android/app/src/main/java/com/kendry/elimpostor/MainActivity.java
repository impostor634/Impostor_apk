package com.kendry.elimpostor;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
