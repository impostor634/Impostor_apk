var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_express = __toESM(require("express"), 1);
var import_vite = require("vite");
var import_path = __toESM(require("path"), 1);
var import_fs = __toESM(require("fs"), 1);
var import_jszip = __toESM(require("jszip"), 1);
async function startServer() {
  const app = (0, import_express.default)();
  const PORT = 3e3;
  const isProduction = process.env.NODE_ENV === "production";
  function addDirectoryToZip(zip, dirPath, rootDir) {
    const items = import_fs.default.readdirSync(dirPath);
    for (const item of items) {
      if (item === "node_modules" || item === "dist" || item === ".git" || item === ".cache" || item === ".DS_Store") {
        continue;
      }
      const fullPath = import_path.default.join(dirPath, item);
      const relativePath = import_path.default.relative(rootDir, fullPath);
      if (relativePath.includes("android/.gradle") || relativePath.includes("android/app/build") || relativePath.includes("android/build") || relativePath.includes("android/.idea")) {
        continue;
      }
      const stat = import_fs.default.statSync(fullPath);
      if (stat.isDirectory()) {
        addDirectoryToZip(zip, fullPath, rootDir);
      } else {
        const fileData = import_fs.default.readFileSync(fullPath);
        zip.file(relativePath, fileData);
      }
    }
  }
  app.get("/api/download-zip", async (req, res) => {
    try {
      const zip = new import_jszip.default();
      const rootDir = process.cwd();
      addDirectoryToZip(zip, rootDir, rootDir);
      const zipBuffer = await zip.generateAsync({
        type: "nodebuffer",
        compression: "DEFLATE",
        compressionOptions: { level: 9 }
      });
      res.setHeader("Content-Type", "application/zip");
      res.setHeader(
        "Content-Disposition",
        'attachment; filename="el-impostor-proyecto-apk.zip"'
      );
      res.setHeader("Content-Length", zipBuffer.length.toString());
      res.send(zipBuffer);
    } catch (error) {
      console.error("Error al generar ZIP:", error);
      res.status(500).json({ error: "Error al generar el archivo ZIP" });
    }
  });
  if (!isProduction) {
    const vite = await (0, import_vite.createServer)({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = import_path.default.resolve(process.cwd(), "dist");
    app.use(import_express.default.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(import_path.default.resolve(distPath, "index.html"));
    });
  }
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Servidor El Impostor ejecut\xE1ndose en http://0.0.0.0:${PORT}`);
  });
}
startServer();
