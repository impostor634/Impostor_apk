import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import fs from 'fs';
import JSZip from 'jszip';

async function startServer() {
  const app = express();
  const PORT = 3000;
  const isProduction = process.env.NODE_ENV === 'production';

  // Helper recursivo para agregar archivos al ZIP excluyendo carpetas innecesarias
  function addDirectoryToZip(zip: JSZip, dirPath: string, rootDir: string) {
    const items = fs.readdirSync(dirPath);

    for (const item of items) {
      // Ignorar carpetas pesadas o temporales
      if (
        item === 'node_modules' ||
        item === 'dist' ||
        item === '.git' ||
        item === '.cache' ||
        item === '.DS_Store'
      ) {
        continue;
      }

      const fullPath = path.join(dirPath, item);
      const relativePath = path.relative(rootDir, fullPath);

      // Si es parte de la carpeta android, ignorar builds y caches
      if (
        relativePath.includes('android/.gradle') ||
        relativePath.includes('android/app/build') ||
        relativePath.includes('android/build') ||
        relativePath.includes('android/.idea')
      ) {
        continue;
      }

      const stat = fs.statSync(fullPath);
      if (stat.isDirectory()) {
        addDirectoryToZip(zip, fullPath, rootDir);
      } else {
        const fileData = fs.readFileSync(fullPath);
        zip.file(relativePath, fileData);
      }
    }
  }

  // API endpoint para descargar el proyecto en un .ZIP completo
  app.get('/api/download-zip', async (req, res) => {
    try {
      const zip = new JSZip();
      const rootDir = process.cwd();

      addDirectoryToZip(zip, rootDir, rootDir);

      const zipBuffer = await zip.generateAsync({
        type: 'nodebuffer',
        compression: 'DEFLATE',
        compressionOptions: { level: 9 },
      });

      res.setHeader('Content-Type', 'application/zip');
      res.setHeader(
        'Content-Disposition',
        'attachment; filename="el-impostor-proyecto-apk.zip"'
      );
      res.setHeader('Content-Length', zipBuffer.length.toString());
      res.send(zipBuffer);
    } catch (error) {
      console.error('Error al generar ZIP:', error);
      res.status(500).json({ error: 'Error al generar el archivo ZIP' });
    }
  });

  if (!isProduction) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Servidor El Impostor ejecutándose en http://0.0.0.0:${PORT}`);
  });
}

startServer();
